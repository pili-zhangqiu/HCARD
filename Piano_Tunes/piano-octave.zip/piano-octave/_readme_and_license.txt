Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - pinkyfinger ( https://freesound.org/people/pinkyfinger/ )

You can find this pack online at: https://freesound.org/people/pinkyfinger/packs/4409/

License details
---------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this pack
-------------------

  * 68448__pinkyfinger__Piano_G.wav
    * url: https://freesound.org/s/68448/
    * license: Creative Commons 0
  * 68447__pinkyfinger__Piano_G_.wav
    * url: https://freesound.org/s/68447/
    * license: Creative Commons 0
  * 68446__pinkyfinger__Piano_F.wav
    * url: https://freesound.org/s/68446/
    * license: Creative Commons 0
  * 68445__pinkyfinger__Piano_F_.wav
    * url: https://freesound.org/s/68445/
    * license: Creative Commons 0
  * 68444__pinkyfinger__Piano_Eb.wav
    * url: https://freesound.org/s/68444/
    * license: Creative Commons 0
  * 68443__pinkyfinger__Piano_E.wav
    * url: https://freesound.org/s/68443/
    * license: Creative Commons 0
  * 68442__pinkyfinger__Piano_D.wav
    * url: https://freesound.org/s/68442/
    * license: Creative Commons 0
  * 68441__pinkyfinger__Piano_C.wav
    * url: https://freesound.org/s/68441/
    * license: Creative Commons 0
  * 68440__pinkyfinger__Piano_C_.wav
    * url: https://freesound.org/s/68440/
    * license: Creative Commons 0
  * 68439__pinkyfinger__Piano_Bb.wav
    * url: https://freesound.org/s/68439/
    * license: Creative Commons 0
  * 68438__pinkyfinger__Piano_B.wav
    * url: https://freesound.org/s/68438/
    * license: Creative Commons 0
  * 68437__pinkyfinger__Piano_A.wav
    * url: https://freesound.org/s/68437/
    * license: Creative Commons 0


